#!/usr/bin/env python3
"""
═══════════════════════════════════════════════════════════════════════════════
MINIMAL RAG INGEST SCRIPT
═══════════════════════════════════════════════════════════════════════════════

PURPOSE:
--------
Takes ONE .md (markdown) file and stores it in a vector database so it can be
searched and queried later. This is the first step of RAG (Retrieval-Augmented
Generation).

HOW IT WORKS (High Level):
--------------------------
1. Read your .md file from disk
2. Split the text into manageable chunks (512 tokens each)
3. Convert each chunk into vectors (numbers representing meaning)
4. Store vectors in ChromaDB (vector database)
5. Later, queries will search these vectors to find relevant content

PRINCIPLE:
----------
Think of it like this:
- Your file is a book
- We split it into sentences (chunks)
- We convert each sentence to a fingerprint (vector)
- We store the fingerprints in a database
- Later, when you ask a question, we find matching fingerprints

WHAT GETS CREATED:
------------------
./chroma_db/  ← Vector database folder
├─ chroma.db         ← Main database file
├─ data/             ← Vector data
└─ metadata/         ← File information

This folder persists after script ends, so next time you run query script,
it uses the same database.

EXAMPLE RUN:
-----------
$ python3 minimal_ingest.py ADXL362_datasheet.md

Setting up...
✓ Ready

Reading: ADXL362_datasheet.md
Content: 15432 characters
Storing...
✓ Done!

Database now has: 32 chunks

(Now you can query this file with minimal_query.py!)
"""

# ════════════════════════════════════════════════════════════════════════════
# IMPORTS - What libraries we need
# ════════════════════════════════════════════════════════════════════════════

import sys
# sys: System stuff (command-line arguments, exit)

from llama_index.core import VectorStoreIndex, Document, Settings
# VectorStoreIndex: Creates searchable index from documents
# Document: Wraps text with metadata (like a tagged note)
# Settings: Global configuration for embedding/LLM

from llama_index.llms.ollama import Ollama
# Ollama: Connection to language model (not used in ingest, but imported)

from llama_index.embeddings.ollama import OllamaEmbedding
# OllamaEmbedding: Converts text to vectors using Ollama

from llama_index.vector_stores.chroma import ChromaVectorStore
# ChromaVectorStore: Wrapper for ChromaDB for LlamaIndex

from llama_index.core import StorageContext
# StorageContext: Tells LlamaIndex where to store vectors

import chromadb
# chromadb: Vector database library (stores embeddings)


# ════════════════════════════════════════════════════════════════════════════
# CONFIGURATION - Settings you can change
# ════════════════════════════════════════════════════════════════════════════

OLLAMA_URL = "http://10.0.0.38:11434"
# Where is Ollama running?
# 10.0.0.38 = Your Linux PC IP address
# 11434 = Ollama's default port
# Change if Ollama on different machine
# Example: "http://192.168.1.100:11434"

EMBED_MODEL = "nomic-embed-text"
# Which embedding model to use?
# This converts text to vectors (numbers representing meaning)
# Must match what you use in query script!
# Other options: "mistral-embed", "all-minilm"

CHROMA_PATH = "./chroma_db"
# Where to store the vector database
# "./" = current folder
# "chroma_db" = folder name
# Creates folder if doesn't exist
# Must match query script!

COLLECTION_NAME = "documents"
# Name of collection inside ChromaDB
# Like a "table" in a database
# You could have multiple collections
# Must match query script!


# ════════════════════════════════════════════════════════════════════════════
# SETUP PHASE - Initialize everything before processing
# ════════════════════════════════════════════════════════════════════════════

print("Setting up...")
# Tell user we're starting (so they know it's working)

# ──────────────────────────────────────────────────────────────────────────
# STEP 1: Configure the embedding model
# ──────────────────────────────────────────────────────────────────────────

Settings.embed_model = OllamaEmbedding(
    # Settings.embed_model: Global embedding configuration
    # This tells LlamaIndex how to convert text to vectors
    
    model_name=EMBED_MODEL,
    # Which embedding model to use (nomic-embed-text)
    # This model is lightweight but effective
    
    base_url=OLLAMA_URL
    # Where is Ollama running? (http://10.0.0.38:11434)
    # Script will connect here to generate embeddings
)

# ──────────────────────────────────────────────────────────────────────────
# STEP 2: Configure chunking parameters
# ──────────────────────────────────────────────────────────────────────────

Settings.chunk_size = 512
# Split document into 512-token chunks
# Why? So each piece fits in the model's context window
# Tokens ≈ 4 characters, so 512 tokens ≈ 2000 characters
# Too large: Won't fit in context
# Too small: Lose useful context
# 512 is a good middle ground

Settings.chunk_overlap = 64
# Chunks overlap by 64 tokens
# Why? So no important info is lost between chunks
# Example:
#   Chunk 1: tokens 1-512
#   Chunk 2: tokens 449-960 (overlap = 64)
#   Chunk 3: tokens 897-1408
# Overlap ensures context isn't cut off

# ──────────────────────────────────────────────────────────────────────────
# STEP 3: Initialize vector database (ChromaDB)
# ──────────────────────────────────────────────────────────────────────────

chroma_client = chromadb.PersistentClient(path=CHROMA_PATH)
# chromadb.PersistentClient: Create database that survives script ending
# path=CHROMA_PATH: Database lives in "./chroma_db/" folder
# "Persistent" = stays after script closes
# Next time: reuses same database (doesn't create new)

chroma_collection = chroma_client.get_or_create_collection(COLLECTION_NAME)
# get_or_create_collection: Get existing collection or create if new
# COLLECTION_NAME = "documents"
# Like getting a "table" in a database
# If "documents" collection exists: use it
# If not: create it

vector_store = ChromaVectorStore(chroma_collection=chroma_collection)
# ChromaVectorStore: Wraps ChromaDB for LlamaIndex
# LlamaIndex needs this wrapper to work with ChromaDB
# Handles behind-the-scenes vector storage details

storage_context = StorageContext.from_defaults(vector_store=vector_store)
# StorageContext: Tells LlamaIndex where to save vectors
# "from_defaults" with vector_store: Use ChromaDB for storage
# This is where documents will be saved

print("✓ Ready\n")
# Setup complete! Tell user we're ready for the file


# ════════════════════════════════════════════════════════════════════════════
# INGEST FUNCTION - The actual work of reading and storing
# ════════════════════════════════════════════════════════════════════════════

def ingest_file(file_path):
    """
    Read a single .md file and store its embeddings in vector database
    
    PROCESS:
    1. Open and read file content
    2. Wrap in Document object with metadata
    3. Create embeddings (convert to vectors)
    4. Store in ChromaDB
    
    Args:
        file_path (str): Path to .md file
                        Example: "README.md" or "/home/user/doc.md"
    """
    
    print(f"Reading: {file_path}")
    # Tell user which file we're reading
    
    # ──────────────────────────────────────────────────────────────────────
    # STEP 1: Read file from disk
    # ──────────────────────────────────────────────────────────────────────
    
    with open(file_path, "r") as f:
        # open(): Open the file
        # "r": Read mode (not write)
        # f: File object
        # "with": Automatically close file when done
        
        text = f.read()
        # Read all content into one string
        # Example: "# My Document\n\nContent here..."
    
    print(f"Content: {len(text)} characters")
    # Show user file size for feedback
    # len(text): How many characters we read
    
    # ──────────────────────────────────────────────────────────────────────
    # STEP 2: Create a Document object
    # ──────────────────────────────────────────────────────────────────────
    
    document = Document(
        # Document: LlamaIndex class that wraps text + metadata
        # Like: a piece of paper with content + labels
        
        text=text,
        # The actual file content (everything we read)
        # This is what will be chunked and embedded
        
        metadata={
            # metadata: Information ABOUT the document
            # Not the content, but info about it
            # Retrieved later when document is found
            
            "filename": file_path,
            # Original filename for reference
            # Example: "ADXL362.md"
            
            "type": "markdown"
            # What type of file is this?
            # "markdown" = .md file
            # (Could be "code", "datasheet", etc.)
        }
    )
    
    # ──────────────────────────────────────────────────────────────────────
    # STEP 3: Create embeddings and store in database
    # ──────────────────────────────────────────────────────────────────────
    
    print("Storing...")
    # Tell user we're processing (might take a moment)
    
    VectorStoreIndex.from_documents(
        # VectorStoreIndex.from_documents: Main function that:
        # 1. Splits document into chunks (512 tokens)
        # 2. Converts each chunk to embedding (vector)
        # 3. Stores in ChromaDB
        
        [document],
        # [document]: List containing ONE document
        # Wrapped in brackets to make it a list
        # Could be multiple: [doc1, doc2, doc3]
        
        storage_context=storage_context,
        # Where to store vectors (ChromaDB we set up)
        # Tells LlamaIndex to save to ./chroma_db/
        
        show_progress=False
        # Don't show progress bar (keeps output clean)
        # True would show: ████████░░ 80%
    )
    
    print("✓ Done!\n")
    # Storing complete!
    
    # ──────────────────────────────────────────────────────────────────────
    # STEP 4: Show results
    # ──────────────────────────────────────────────────────────────────────
    
    total_chunks = chroma_collection.count()
    # count(): How many chunks total in database?
    # If first file: probably 20-50 chunks
    # If second file: adds to existing chunks
    # Example: First file = 32 chunks, second = 45 chunks, total = 77
    
    print(f"Database now has: {total_chunks} chunks")
    # Tell user total stored
    # Chunks are document pieces (512 tokens each)


# ════════════════════════════════════════════════════════════════════════════
# MAIN - Get filename from command line and ingest
# ════════════════════════════════════════════════════════════════════════════

if len(sys.argv) < 2:
    # sys.argv: Command-line arguments
    # sys.argv[0]: Script name ("minimal_ingest.py")
    # sys.argv[1]: First argument (filename)
    # len(sys.argv) < 2: User didn't provide filename
    
    print("Usage:")
    print("  python3 minimal_ingest.py <file.md>")
    # Show how to use script
    
    print("\nExample:")
    print("  python3 minimal_ingest.py README.md")
    # Show a real example
    
    sys.exit(1)
    # Exit with error code 1 (something went wrong)

file_path = sys.argv[1]
# Get the filename user provided
# Example: user runs: python3 minimal_ingest.py ADXL362.md
# Then file_path = "ADXL362.md"

try:
    # try/except: Catch errors gracefully
    # If something goes wrong, show user the error
    
    ingest_file(file_path)
    # Call our function to ingest the file
    # This does all the work
    
except Exception as e:
    # If anything goes wrong above
    # e: The error message
    
    print(f"Error: {e}")
    # Show user what went wrong
    # Example: "Error: [Errno 2] No such file or directory: 'notfound.md'"
    
    sys.exit(1)
    # Exit with error code 1
