#!/usr/bin/env python3
"""
═══════════════════════════════════════════════════════════════════════════════
MINIMAL RAG QUERY SCRIPT
═══════════════════════════════════════════════════════════════════════════════

PURPOSE:
--------
Ask questions about the document you ingested with minimal_ingest.py
The script searches the vector database for relevant content and gets an answer
from the language model.

HOW IT WORKS (High Level):
--------------------------
1. Load the vector database (created by ingest script)
2. Take your question
3. Convert question to vector (same as chunks from ingest)
4. Search database for similar vectors (find relevant chunks)
5. Send question + relevant chunks to LLM (language model)
6. LLM generates an answer based on the context
7. Stream answer back to you (word by word)

PRINCIPLE - RAG (Retrieval-Augmented Generation):
--------------------------------------------------
Traditional LLM:
  Question → LLM → Answer (based on training data only)

RAG (better):
  Question → Search Database → Find Relevant Chunks → LLM → Answer
  
The key: LLM gets CONTEXT (your document!) when answering
So it can give accurate answers about YOUR specific file

RETRIEVAL:   Search vector database for chunks similar to question
AUGMENT:     Add those chunks as context to the question
GENERATE:    LLM generates answer with that context

EXAMPLE RUN:
-----------
$ python3 minimal_query.py "What is the supply voltage?"

Loading database...

✓ Ready

Question: What is the supply voltage?

Searching and thinking...

Answer:
----------------------------------------------------------------------
The supply voltage range is 1.6V to 3.5V...
----------------------------------------------------------------------

Sources (5 chunks used):
  1. Relevance: 0.892
  2. Relevance: 0.756
  3. Relevance: 0.634
"""

# ════════════════════════════════════════════════════════════════════════════
# IMPORTS - What libraries we need
# ════════════════════════════════════════════════════════════════════════════

import sys
# sys: Command-line arguments, exit

from llama_index.core import VectorStoreIndex, Settings
# VectorStoreIndex: Queryable index (can search vectors)
# Settings: Global configuration

from llama_index.llms.ollama import Ollama
# Ollama: Connection to language model
# This will generate the answers

from llama_index.embeddings.ollama import OllamaEmbedding
# OllamaEmbedding: Convert text to vectors
# Used to convert your question into vector for searching

from llama_index.vector_stores.chroma import ChromaVectorStore
# ChromaVectorStore: Wrapper for ChromaDB for LlamaIndex

from llama_index.core import StorageContext
# StorageContext: Connection to storage

import chromadb
# chromadb: Vector database library


# ════════════════════════════════════════════════════════════════════════════
# CONFIGURATION - Settings (must match ingest script!)
# ════════════════════════════════════════════════════════════════════════════

OLLAMA_URL = "http://10.0.0.38:11434"
# Where is Ollama running?
# Must be SAME as ingest script
# 10.0.0.38 = Linux PC
# 11434 = Ollama port

LLM_MODEL = "qwen2.5-coder:7b"
# Which model will GENERATE answers?
# This is different from embedding model
# LLM_MODEL: Understands and answers questions
# EMBED_MODEL: Converts text to vectors

EMBED_MODEL = "nomic-embed-text"
# Which model converts text to vectors?
# Must be SAME as ingest script!
# If different: won't find documents correctly

CHROMA_PATH = "./chroma_db"
# Where is the vector database?
# Must be SAME as ingest script
# This must exist (created by ingest script)

COLLECTION_NAME = "documents"
# Which collection to search?
# Must be SAME as ingest script


# ════════════════════════════════════════════════════════════════════════════
# SETUP PHASE - Initialize everything
# ════════════════════════════════════════════════════════════════════════════

print("Loading database...\n")
# Tell user we're starting (might take a moment)

# ──────────────────────────────────────────────────────────────────────────
# STEP 1: Setup the language model (for generating answers)
# ──────────────────────────────────────────────────────────────────────────

Settings.llm = Ollama(
    # Settings.llm: Global language model
    # This will be used to answer questions
    
    model=LLM_MODEL,
    # Which model? qwen2.5-coder:7b
    # This model will understand questions and generate answers
    
    base_url=OLLAMA_URL
    # Where is Ollama? http://10.0.0.38:11434
    # Script connects here to use the model
)

# ──────────────────────────────────────────────────────────────────────────
# STEP 2: Setup the embedding model (for searching vectors)
# ──────────────────────────────────────────────────────────────────────────

Settings.embed_model = OllamaEmbedding(
    # Settings.embed_model: How to convert text to vectors
    # Used to search the vector database
    
    model_name=EMBED_MODEL,
    # Which embedding model? nomic-embed-text
    # Must match ingest script!
    # Different embedding = wrong search results
    
    base_url=OLLAMA_URL
    # Where is Ollama? http://10.0.0.38:11434
)

# ──────────────────────────────────────────────────────────────────────────
# STEP 3: Load the vector database (created by ingest script)
# ──────────────────────────────────────────────────────────────────────────

chroma_client = chromadb.PersistentClient(path=CHROMA_PATH)
# Load database from disk
# path=CHROMA_PATH: "./chroma_db/"
# This folder must exist (created by ingest script)
# If not found: ERROR!

chroma_collection = chroma_client.get_or_create_collection(COLLECTION_NAME)
# Get the collection named "documents"
# Must match ingest script!
# This is where we search for chunks

vector_store = ChromaVectorStore(chroma_collection=chroma_collection)
# Wrap ChromaDB for LlamaIndex
# Let's LlamaIndex work with ChromaDB

storage_context = StorageContext.from_defaults(vector_store=vector_store)
# Tell LlamaIndex where to read from
# Uses vector_store (ChromaDB)

index = VectorStoreIndex.from_vector_store(
    # Create queryable index
    # This can search the vectors
    
    vector_store,
    # Use ChromaDB as the source
    # index.query() will search here
    
    storage_context=storage_context
    # Where to read from
)

print("✓ Ready\n")
# Setup complete!


# ════════════════════════════════════════════════════════════════════════════
# QUERY FUNCTION - Ask a question and get an answer
# ════════════════════════════════════════════════════════════════════════════

def ask_question(question):
    """
    Ask a question about the document
    
    PROCESS:
    1. Create query engine from index
    2. Query converts question to vector
    3. Searches database for similar vectors
    4. Gets TOP 5 most similar chunks
    5. Sends chunks + question to LLM
    6. LLM generates answer
    7. Stream answer back to user
    
    Args:
        question (str): Your question
                       Example: "What is the supply voltage?"
    """
    
    print(f"Question: {question}\n")
    # Show user their question
    
    print("Searching and thinking...\n")
    # Tell user we're processing (might take a moment)
    
    # ──────────────────────────────────────────────────────────────────────
    # STEP 1: Create query engine
    # ──────────────────────────────────────────────────────────────────────
    
    query_engine = index.as_query_engine(
        # index.as_query_engine: Turn index into a query engine
        # Query engine can search vectors and get LLM answers
        
        similarity_top_k=5,
        # Get TOP 5 most similar chunks from database
        # Why 5? Good balance between context and speed
        # Fewer (1-2): Only most relevant (fast)
        # More (10+): More context but slower
        
        streaming=True
        # Stream response token-by-token
        # Like ChatGPT (word by word)
        # Not wait for full response at once
    )
    
    # ──────────────────────────────────────────────────────────────────────
    # STEP 2: Execute query
    # ──────────────────────────────────────────────────────────────────────
    
    response = query_engine.query(question)
    # query.query(question): The actual search and answer
    # 
    # What happens behind the scenes:
    # 1. Convert question to vector
    # 2. Search database for similar vectors (find chunks)
    # 3. Get TOP 5 most similar chunks
    # 4. Build prompt: "Here are chunks: [chunks]. Question: [question]"
    # 5. Send to LLM
    # 6. LLM reads chunks + question, generates answer
    # 7. Return response object with:
    #    - response.response_gen: Token generator (streaming)
    #    - response.source_nodes: Which chunks were used
    
    # ──────────────────────────────────────────────────────────────────────
    # STEP 3: Print answer (streaming)
    # ──────────────────────────────────────────────────────────────────────
    
    print("Answer:")
    print("-" * 70)
    # Print header for answer section
    
    for token in response.response_gen:
        # response.response_gen: Generator that yields tokens
        # Loops through answer one token at a time
        # Token = a word or piece of word
        
        print(token, end="", flush=True)
        # end="": Don't add newline after each token
        # flush=True: Print immediately (don't buffer)
        # Result: Answer appears like it's being typed
    
    print("\n" + "-" * 70)
    # End of answer
    
    # ──────────────────────────────────────────────────────────────────────
    # STEP 4: Show which document chunks were used
    # ──────────────────────────────────────────────────────────────────────
    
    print(f"\nSources ({len(response.source_nodes)} chunks used):")
    # response.source_nodes: List of chunks that were used
    # len(response.source_nodes): How many chunks? (usually 5)
    # Each chunk is a piece of your ingested document
    
    for i, node in enumerate(response.source_nodes, 1):
        # enumerate: Loop with counter (i = 1, 2, 3, ...)
        # node: One chunk that was used
        
        score = node.score or 0
        # node.score: Relevance score (0.0 to 1.0)
        # 1.0 = perfect match
        # 0.0 = no match
        # or 0: If None, use 0
        
        print(f"  {i}. Relevance: {score:.3f}")
        # Show which chunk and how relevant
        # {score:.3f}: Show score with 3 decimal places
        # Example: 0.892, 0.756, 0.634


# ════════════════════════════════════════════════════════════════════════════
# MAIN - Get question from command line and ask it
# ════════════════════════════════════════════════════════════════════════════

if len(sys.argv) < 2:
    # sys.argv: Command-line arguments
    # sys.argv[0]: Script name ("minimal_query.py")
    # sys.argv[1]: First argument (question)
    # len(sys.argv) < 2: User didn't provide question
    
    print("Usage:")
    print("  python3 minimal_query.py \"Your question here\"")
    # Show how to use
    
    print("\nExample:")
    print("  python3 minimal_query.py \"What is this about?\"")
    # Show real example
    
    sys.exit(1)
    # Exit with error

question = " ".join(sys.argv[1:])
# Get the question from command line
# sys.argv[1:]: All arguments after script name
# " ".join(): Join them with spaces
# Example: user runs: python3 minimal_query.py "What" "is" "voltage?"
# Result: question = "What is voltage?"

try:
    # try/except: Catch errors gracefully
    
    ask_question(question)
    # Call function to process question and show answer
    
except Exception as e:
    # If anything goes wrong
    # e: Error message
    
    print(f"Error: {e}")
    # Show user what went wrong
    # Example: "Error: connection refused"
    # Example: "Error: no data in database"
    
    sys.exit(1)
    # Exit with error code
