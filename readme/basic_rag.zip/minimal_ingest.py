#!/usr/bin/env python3
"""
Minimal RAG Ingest
==================
Reads ONE .md file and stores it in vector database.
That's it. No recursion, no folders, just one file.
"""

import sys
from llama_index.core import VectorStoreIndex, Document, Settings
from llama_index.llms.ollama import Ollama
from llama_index.embeddings.ollama import OllamaEmbedding
from llama_index.vector_stores.chroma import ChromaVectorStore
from llama_index.core import StorageContext
import chromadb


# ════════════════════════════════════════════════════════════════════════════
# CONFIG
# ════════════════════════════════════════════════════════════════════════════

OLLAMA_URL = "http://10.0.0.38:11434"
EMBED_MODEL = "nomic-embed-text"
CHROMA_PATH = "./chroma_db"
COLLECTION_NAME = "documents"


# ════════════════════════════════════════════════════════════════════════════
# SETUP
# ════════════════════════════════════════════════════════════════════════════

print("Setting up...")

Settings.embed_model = OllamaEmbedding(
    model_name=EMBED_MODEL,
    base_url=OLLAMA_URL
)

Settings.chunk_size = 512
Settings.chunk_overlap = 64

chroma_client = chromadb.PersistentClient(path=CHROMA_PATH)
chroma_collection = chroma_client.get_or_create_collection(COLLECTION_NAME)
vector_store = ChromaVectorStore(chroma_collection=chroma_collection)
storage_context = StorageContext.from_defaults(vector_store=vector_store)

print("✓ Ready\n")


# ════════════════════════════════════════════════════════════════════════════
# INGEST
# ════════════════════════════════════════════════════════════════════════════

def ingest_file(file_path):
    """Read file and store in database"""
    
    print(f"Reading: {file_path}")
    
    # Read file
    with open(file_path, "r") as f:
        text = f.read()
    
    print(f"Content: {len(text)} characters")
    
    # Create document
    document = Document(
        text=text,
        metadata={
            "filename": file_path,
            "type": "markdown"
        }
    )
    
    # Store in database
    print("Storing...")
    VectorStoreIndex.from_documents(
        [document],
        storage_context=storage_context,
        show_progress=False
    )
    
    print("✓ Done!\n")
    
    total_chunks = chroma_collection.count()
    print(f"Database now has: {total_chunks} chunks")


# ════════════════════════════════════════════════════════════════════════════
# MAIN
# ════════════════════════════════════════════════════════════════════════════

if len(sys.argv) < 2:
    print("Usage:")
    print("  python3 minimal_ingest.py <file.md>")
    print("\nExample:")
    print("  python3 minimal_ingest.py README.md")
    sys.exit(1)

file_path = sys.argv[1]

try:
    ingest_file(file_path)
except Exception as e:
    print(f"Error: {e}")
    sys.exit(1)
