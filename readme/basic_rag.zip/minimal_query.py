#!/usr/bin/env python3
"""
Minimal RAG Query
=================
Ask ONE question about your stored document.
That's it. No loops, no history, no fancy stuff.
"""

import sys
from llama_index.core import VectorStoreIndex, Settings
from llama_index.llms.ollama import Ollama
from llama_index.embeddings.ollama import OllamaEmbedding
from llama_index.vector_stores.chroma import ChromaVectorStore
from llama_index.core import StorageContext
import chromadb


# ════════════════════════════════════════════════════════════════════════════
# CONFIG
# ════════════════════════════════════════════════════════════════════════════

OLLAMA_URL = "http://10.0.0.38:11434"
LLM_MODEL = "qwen2.5-coder:7b"
EMBED_MODEL = "nomic-embed-text"
CHROMA_PATH = "./chroma_db"
COLLECTION_NAME = "documents"


# ════════════════════════════════════════════════════════════════════════════
# SETUP
# ════════════════════════════════════════════════════════════════════════════

print("Loading database...\n")

# Setup LLM
Settings.llm = Ollama(
    model=LLM_MODEL,
    base_url=OLLAMA_URL
)

# Setup embeddings
Settings.embed_model = OllamaEmbedding(
    model_name=EMBED_MODEL,
    base_url=OLLAMA_URL
)

# Load database
chroma_client = chromadb.PersistentClient(path=CHROMA_PATH)
chroma_collection = chroma_client.get_or_create_collection(COLLECTION_NAME)
vector_store = ChromaVectorStore(chroma_collection=chroma_collection)
storage_context = StorageContext.from_defaults(vector_store=vector_store)
index = VectorStoreIndex.from_vector_store(vector_store, storage_context=storage_context)

print("✓ Ready\n")


# ════════════════════════════════════════════════════════════════════════════
# QUERY
# ════════════════════════════════════════════════════════════════════════════

def ask_question(question):
    """Ask a question and get answer"""
    
    print(f"Question: {question}\n")
    print("Searching and thinking...\n")
    
    # Create query engine
    query_engine = index.as_query_engine(similarity_top_k=5, streaming=True)
    
    # Get response
    response = query_engine.query(question)
    
    # Print answer
    print("Answer:")
    print("-" * 70)
    
    for token in response.response_gen:
        print(token, end="", flush=True)
    
    print("\n" + "-" * 70)
    
    # Show sources
    print(f"\nSources ({len(response.source_nodes)} chunks used):")
    for i, node in enumerate(response.source_nodes, 1):
        score = node.score or 0
        print(f"  {i}. Relevance: {score:.3f}")


# ════════════════════════════════════════════════════════════════════════════
# MAIN
# ════════════════════════════════════════════════════════════════════════════

if len(sys.argv) < 2:
    print("Usage:")
    print("  python3 minimal_query.py \"Your question here\"")
    print("\nExample:")
    print("  python3 minimal_query.py \"What is this about?\"")
    sys.exit(1)

question = " ".join(sys.argv[1:])

try:
    ask_question(question)
except Exception as e:
    print(f"Error: {e}")
    sys.exit(1)
